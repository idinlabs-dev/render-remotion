# Peter Episode1 — Remotion 3D Explainer

Project video explainer 3D gaya mainan/clay low-poly dari narasi `peterfulleps1.mp3` dan subtitle `peter.srt`. Format **1280×720, 16:9, 30 fps**. Project ini tidak dirender di sandbox; render dilakukan melalui GitHub Actions.

## Asumsi
- Peter divisualisasikan sebagai tokoh thriller-fantasi dengan versi tua dan versi muda.
- Dunia utama adalah toko buku bekas yang berubah menjadi lokasi penyergapan.
- Tidak ada model `.glb`; seluruh objek dibuat dari bentuk dasar Three.js.
- Remotion dipin ke `4.0.250`, React 18 + R3F 8.

## Struktur
- `src/world/`: dunia, toko buku, karakter, objek.
- `src/overlay/`: chapter title, subtitle per kata, watermark.
- `src/camera.ts`: shot kamera dan fungsi `project()`/`cue()`.
- `src/timing.json`, `timing.cjs`, `narasi.txt`: timing dari SRT/audio.
- `public/narasi.mp3`: audio narasi.
- `.github/workflows/render-remotion.yml`: workflow manual.

## Render di GitHub Actions
1. Upload folder ini ke repository.
2. Buka tab **Actions** → **Render Remotion** → **Run workflow**.
3. Workflow menjalankan `npm install`, menghitung ulang timing, membuat still, merender MP4, lalu mengunggah artifact.

Untuk lokal: `npm install`, lalu `npm run timing`. Render satu frame per adegan lebih dulu dengan `npm run still -- --frame=N`; setelah posisi kamera/cahaya tepat, jalankan `npm run render`.

## Verifikasi dan batasan
Kode dirancang mengikuti pipeline deterministik: animasi berbasis `t`, tanpa state/timer/Math.random/useFrame; overlay memakai timing; warna berada di `src/theme.ts`; `Sequence` tidak digunakan di dalam ThreeCanvas. Tampilan 3D, kecocokan kombinasi paket, flag Chromium `swangle`, waktu render, dan kualitas visual belum dapat diuji di sandbox ini karena dependency Remotion/Three.js tidak terpasang dan video tidak dirender sesuai permintaan.
