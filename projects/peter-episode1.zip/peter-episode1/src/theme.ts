export const theme = {
  bg: '#BFE6F2', ink: '#172536', white: '#FFFDF7', navy: '#173B63', red: '#C9474D', gold: '#E7B64A', teal: '#3B9C9A', wood: '#9B6547', skin: '#E9B49A', coat: '#344B65', coatDark: '#233448', floor: '#D9C9B5', shadow: '#8B7D78', fog: '#DDF3F5', girlCoat: '#9B6BAA', enemyCoat: '#4A3B46', youngCoat: '#1F2C49', hair: '#1B1B22', hairGirl: '#4B273B', hairGray: '#D0D1D3', girlSkin: '#DFA88F', font: 'Arial, sans-serif'
} as const;
export const W = 1920, H = 1080, FPS = 30;
