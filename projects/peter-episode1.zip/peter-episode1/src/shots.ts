export type Shot={start:number;end:number;kind:'future'|'shop'|'action'|'memory'|'kitchen'};
export const shots:Shot[]=[{start:0,end:30.746,kind:'future'},{start:30.746,end:130.302,kind:'shop'},{start:130.302,end:198.964,kind:'action'},{start:198.964,end:227.567,kind:'memory'},{start:227.567,end:322.273,kind:'kitchen'}];
export function activeShot(t:number){return shots.find(s=>t>=s.start&&t<s.end)||shots[shots.length-1];}
