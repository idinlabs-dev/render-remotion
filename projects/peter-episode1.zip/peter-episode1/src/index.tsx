import React from 'react'; import {registerRoot, Composition} from 'remotion'; import {Video} from './Video'; import {FPS,W,H} from './theme';
export const RemotionRoot=()=> <Composition id="PeterEpisode1" component={Video} durationInFrames={Math.ceil(322.273*FPS)} fps={FPS} width={W} height={H}/>;
registerRoot(RemotionRoot);
