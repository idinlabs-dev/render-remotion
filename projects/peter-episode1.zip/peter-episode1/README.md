# peter-episode1

Project Remotion explainer 3D format **1920x1080, 16:9, 30 FPS**, durasi sekitar 5:22. Visual dibuat dari kode Three.js dengan staging sinematik bergaya stylized 3D, bukan rekaman atau model eksternal.

## Menjalankan lokal

```bash
npm install
npm run timing
npm run still -- --frame=0
npm run still -- --frame=4500
npm run render
```

Workflow repository Anda memakai `npm install`, mencari `src/index.ts`, membaca `render.json`, lalu merender composition `PeterEpisode1`. Jangan menyertakan `node_modules` ketika ZIP diunggah.

## Split render

`render.json` menetapkan `segmentSeconds: 60`. Workflow satu-perintah yang ada di repository masih merender seluruh video sekaligus. Gunakan file workflow pengganti yang disertakan di luar ZIP (`render-remotion-split.yml`) agar GitHub Actions merender rentang 60 detik per job, menggabungkannya dengan FFmpeg, lalu mengunggah satu MP4 final. Ini diperlukan karena workflow saat ini belum mempunyai langkah split/concat.

## Struktur

- `src/index.ts`: composition 1920x1080, 30 FPS.
- `src/Video.tsx`: render deterministik berbasis `t = frame / fps`.
- `src/world.tsx`: karakter, toko buku, arena aksi, dapur.
- `src/shots.ts` dan `src/camera.ts`: shot dan kamera.
- `src/timing.json`, `timing.cjs`, `public/peter.srt`: sumber cue subtitle.
- `public/peterfulleps1.mp3`: audio narasi.

Tampilan 3D belum dirender di sandbox ini; still check di GitHub Actions adalah pemeriksaan visual pertama yang disarankan.
