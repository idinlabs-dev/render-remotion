import React from 'react'; import {Composition} from 'remotion'; import {Video} from './Video'; import timing from './timing.json';
export const RemotionRoot=()=> <Composition id="PeterEpisode1" component={Video} durationInFrames={Math.ceil(timing.duration*timing.fps)} fps={30} width={1280} height={720}/>;
