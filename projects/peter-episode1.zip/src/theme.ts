export const theme={
 ink:'#172536', paper:'#FFF8E8', sky:'#9EDCF2', cloud:'#F7FFFF',
 blue:'#2C75D6', red:'#D9485F', gold:'#F4B942', green:'#63B39B',
 wood:'#9A6542', woodLight:'#D9A66D', coat:'#24364D', skin:'#E3A77B',
 shadow:'#17324D', white:'#FFFFFF', black:'#10151D',
 sizes:{title:56,subtitle:25,label:20,watermark:16}
};
