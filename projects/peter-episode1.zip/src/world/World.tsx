import React from 'react'; import {CanvasTexture} from 'three'; import {Character} from './Character'; import {theme} from '../theme';
const Book=({p=[0,0,0] as any,c=theme.blue})=><mesh position={p} castShadow><boxGeometry args={[.75,.12,.5]}/><meshStandardMaterial color={c} roughness={.85}/></mesh>;
export const World=({t}:{t:number})=>{const young=t>244; const fight=t>120&&t<205; return <>
 <color attach="background" args={[theme.sky]}/><fog attach="fog" args={[theme.sky,12,30]}/><ambientLight intensity={1.8}/><directionalLight position={[5,10,6]} intensity={2.5} castShadow shadow-mapSize={[1024,1024]}/>
 <mesh rotation={[-Math.PI/2,0,0]} receiveShadow><planeGeometry args={[30,30]}/><meshStandardMaterial color={theme.paper}/></mesh>
 <group position={[0,0,-1]}><mesh position={[0,2,-1]} castShadow><boxGeometry args={[7,4.5,.5]}/><meshStandardMaterial color={theme.woodLight}/></mesh><mesh position={[0,4.2,-.7]}><boxGeometry args={[7.2,.25,.7]}/><meshStandardMaterial color={theme.wood}/></mesh>
 {[-2.5,-1.5,-.5,.5,1.5,2.5].map((x,i)=><Book key={i} p={[x,.5,-.7]} c={[theme.blue,theme.red,theme.gold,theme.green,theme.blue,theme.red][i]}/>)}</group>
 <group position={young?[0,0,0]:[-1,0,0]}><Character young={young} position={[0,0,0]} scale={young?1.15:1}/></group>
 {fight&&<><Character hostile position={[2,0,0]} scale={.95}/><Character hostile position={[3,0,-1]} scale={.9}/></>}
 <group position={[-2,.35,1]}>{[0,1,2,3].map(i=><Book key={i} p={[i*.28,0,0]} c={i%2?theme.blue:theme.red}/>)}</group>
 </>};
