import React from 'react'; import {group} from '@react-three/fiber'; import * as THREE from 'three'; import {theme} from '../theme';
export const Character=({young=false,hostile=false,position=[0,0,0] as any,scale=1}:{young?:boolean;hostile?:boolean;position?:[number,number,number];scale?:number})=><group position={position} scale={scale}>
 <mesh position={[0,1.9,0]} castShadow><sphereGeometry args={[.62,16,12]}/><meshStandardMaterial color={theme.skin} roughness={.8}/></mesh>
 <mesh position={[0,2.35,0]} castShadow><sphereGeometry args={[.66,16,8]}/><meshStandardMaterial color={theme.black} roughness={.9}/></mesh>
 <mesh position={[0,1.05,0]} castShadow><capsuleGeometry args={[.48,.9,8,12]}/><meshStandardMaterial color={hostile?theme.red:theme.coat} roughness={.8}/></mesh>
 {[-.3,.3].map((x,i)=><mesh key={i} position={[x,1.95,.55]}><sphereGeometry args={[.07,8,8]}/><meshStandardMaterial color={theme.red}/></mesh>)}
 <mesh position={[0,2.0,.59]} rotation={[0,0,0]}><boxGeometry args={[.28,.05,.03]}/><meshStandardMaterial color={theme.ink}/></mesh>
 {[-.28,.28].map((x,i)=><group key={i} position={[x,0.35,0]}><mesh rotation={[0,0,i?-.1:.1]} castShadow><capsuleGeometry args={[.16,.75,6,8]}/><meshStandardMaterial color={theme.coat}/></mesh></group>)}
</group>;
