import * as THREE from 'three';
export type Shot={cue:number;dur:number;from:{pos:[number,number,number];look:[number,number,number];fov:number};to:{pos:[number,number,number];look:[number,number,number];fov:number}};
export const shots:Shot[]=[
 {cue:0,dur:7,from:{pos:[8,5,12],look:[0,1,0],fov:42},to:{pos:[4,3,9],look:[0,1,0],fov:38}},
 {cue:30.746,dur:15,from:{pos:[7,4,10],look:[0,1,0],fov:42},to:{pos:[3,2.5,7],look:[0,1,0],fov:36}},
 {cue:76.126,dur:16,from:{pos:[5,2.5,8],look:[0,1,0],fov:38},to:{pos:[2,2,6],look:[0,1,0],fov:34}},
 {cue:124.537,dur:19,from:{pos:[8,4,10],look:[0,1,0],fov:40},to:{pos:[5,3,8],look:[0,1,0],fov:35}},
 {cue:198.964,dur:25,from:{pos:[-5,3,8],look:[0,1,0],fov:40},to:{pos:[-2,2.5,6],look:[0,1,0],fov:36}},
 {cue:243.931,dur:35,from:{pos:[4,3,9],look:[0,1,0],fov:40},to:{pos:[1,2,6],look:[0,1,0],fov:32}},
 {cue:303.325,dur:19,from:{pos:[7,4,11],look:[0,1,0],fov:42},to:{pos:[3,3,7],look:[0,1,0],fov:35}}
];
const ease=(x:number)=>x*x*(3-2*x);
export function cameraAt(t:number){let s=shots[0]; for(const q of shots) if(t>=q.cue)s=q; const p=Math.min(1,Math.max(0,(t-s.cue)/s.dur)); const e=ease(p); const lerp=(a:number,b:number)=>a+(b-a)*e; return {position:s.from.pos.map((v,i)=>lerp(v,s.to.pos[i])) as [number,number,number],look:s.from.look.map((v,i)=>lerp(v,s.to.look[i])) as [number,number,number],fov:lerp(s.from.fov,s.to.fov)};}
export function project(point:[number,number,number], cam:ReturnType<typeof cameraAt>, width:number,height:number){const c=new THREE.PerspectiveCamera(cam.fov,width/height,.1,1000); c.position.set(...cam.position); c.lookAt(...cam.look); const v=new THREE.Vector3(...point).project(c); return {x:(v.x+1)*width/2,y:(1-v.y)*height/2,visible:v.z<1};}
export function cue(word:string, sentence:any[]){const q=word.toLowerCase(); for(const s of sentence) for(const w of s.words||[]) if(w.word.toLowerCase()===q)return w.start; throw new Error(`Cue tidak ditemukan: ${word}`);}
