# Peter Comic Action — Remotion

Video Remotion 16:9 (1920x1080), 30 fps, dengan motion graphic, subtitle Bahasa Indonesia, narasi, musik, dan SFX.

## Jalankan lokal / GitHub workflow

```bash
npm install
npm run start
# render penuh:
npm run render
```

Render command:

```bash
npx remotion render src/index.ts Peter out/peter.mp4 --concurrency=6 --crf=20 --audio-bitrate=192k
```

`public/img` berisi 42 panel comic, `public/audio` berisi narasi dan musik, dan `public/sfx` berisi efek suara. File `src/scenes.ts` mengatur urutan panel, timing, motion graphic, dan cue SFX.
