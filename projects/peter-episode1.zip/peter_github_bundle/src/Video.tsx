import React from 'react';
import {AbsoluteFill, Audio, Img, Sequence, interpolate, random, staticFile, useCurrentFrame, useVideoConfig, Easing} from 'remotion';
import {loadFont} from '@remotion/fonts';
import {SCENES, sceneTimes, cues, FPS, TOTAL_FRAMES, MG, Scene} from './scenes';
import * as G from './mg';

loadFont({family: 'Bangers', url: staticFile('fonts/bangers.woff2'), weight: '400'});
loadFont({family: 'Oswald', url: staticFile('fonts/oswald600.woff2'), weight: '600'});
loadFont({family: 'Oswald', url: staticFile('fonts/oswald700.woff2'), weight: '700'});

const OVERLAP = 8;
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

const renderMG = (m: MG) => {
  const p = m.p || {};
  switch (m.k) {
    case 'tag': return <G.Tag {...p} />;
    case 'onoma': return <G.Onoma {...p} />;
    case 'slam': return <G.Slam {...p} />;
    case 'name': return <G.NamePlate {...p} />;
    case 'counter': return <G.Counter {...p} />;
    case 'cross': return <G.Crosshair {...p} />;
    case 'pins': return <G.Pins {...p} />;
    case 'clock': return <G.Clock {...p} />;
    case 'ecg': return <G.ECG {...p} />;
    case 'bell': return <G.Bell {...p} />;
    case 'knife': return <G.KnifeFly {...p} />;
    case 'alert': return <G.Alert {...p} />;
    case 'rule': return <G.RuleCard {...p} />;
    case 'bars': return <G.Bars {...p} />;
    case 'meter': return <G.Meter {...p} />;
    case 'stamp': return <G.Stamp {...p} />;
    case 'quote': return <G.Quote {...p} />;
    case 'smoke': return <G.Smoke {...p} />;
    case 'coins': return <G.Coins {...p} />;
    case 'shock': return <G.ShockRing {...p} />;
    default: return null;
  }
};

const TONES: Record<string, string> = {
  sepia: 'sepia(0.85) contrast(1.05) saturate(0.9)',
  cold: 'saturate(0.9) hue-rotate(-6deg) brightness(0.96)',
  dim: 'brightness(0.82) contrast(1.1)',
  warm: 'saturate(1.08) brightness(1.02)',
};

const SceneView: React.FC<{sc: Scene; first: boolean; baseLen: number}> = ({sc, first, baseLen}) => {
  const f = useCurrentFrame();
  const {fps, durationInFrames} = useVideoConfig();
  const t = f / fps;
  const p = Math.min(1, f / Math.max(1, baseLen));
  const e = Easing.inOut(Easing.quad)(p);
  const amt = sc.amt ?? 0.12;
  let scale = 1.05, tx = 0, ty = 0;
  switch (sc.cam) {
    case 'in': scale = 1.04 + amt * e; break;
    case 'out': scale = 1.04 + amt - amt * e; break;
    case 'left': scale = 1.1 + amt * 0.2; tx = interpolate(e, [0, 1], [50, -50]); break;
    case 'right': scale = 1.1 + amt * 0.2; tx = interpolate(e, [0, 1], [-50, 50]); break;
    case 'up': scale = 1.1 + amt * 0.2; ty = interpolate(e, [0, 1], [40, -40]); break;
    case 'down': scale = 1.1 + amt * 0.2; ty = interpolate(e, [0, 1], [-40, 40]); break;
  }
  let sx = 0, sy = 0;
  (sc.shake || []).forEach(([a, b, amp]) => {
    if (t >= a && t <= b) {
      const decay = 1 - (t - a) / (b - a);
      sx += (random(`shx${f}`) - 0.5) * 2 * amp * (0.4 + decay);
      sy += (random(`shy${f}`) - 0.5) * 2 * amp * (0.4 + decay);
    }
  });
  const fadeIn = first ? 1 : interpolate(f, [0, OVERLAP], [0, 1], clamp);
  const filter = sc.tone ? TONES[sc.tone] : undefined;
  return (
    <AbsoluteFill style={{opacity: fadeIn}}>
      <AbsoluteFill style={{overflow: 'hidden', background: '#000'}}>
        <Img src={staticFile(`img/${sc.img}.jpg`)} style={{width: '100%', height: '100%', objectFit: 'cover', transform: `translate(${tx + sx}px, ${ty + sy}px) scale(${scale})`, filter}} />
      </AbsoluteFill>
      {(sc.speed || []).map(([a, b, col], i) => (
        <Sequence key={`sp${i}`} from={Math.round(a * fps)} durationInFrames={Math.round((b - a) * fps)}>
          <G.FadeWrap><G.SpeedLines color={col || '#fff'} /></G.FadeWrap>
        </Sequence>
      ))}
      {sc.mg.map((m, i) => (
        <Sequence key={`mg${i}`} from={Math.round(m.at * fps)} durationInFrames={Math.max(8, Math.round(m.dur * fps))}>
          <G.FadeWrap>{renderMG(m)}</G.FadeWrap>
        </Sequence>
      ))}
      {(sc.flash || []).map(([a, col], i) => (
        <Sequence key={`fl${i}`} from={Math.round(a * fps)} durationInFrames={14}>
          <G.Flash color={col || '#fff'} />
        </Sequence>
      ))}
      {sc.black ? (
        <Sequence from={Math.max(0, baseLen - Math.round(sc.black * fps))} durationInFrames={Math.round(sc.black * fps) + OVERLAP}>
          <G.BlackFade />
        </Sequence>
      ) : null}
    </AbsoluteFill>
  );
};

const Subtitles: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const idx = cues.findIndex((c) => t >= c.start && t < c.end);
  if (idx < 0) return null;
  const c = cues[idx];
  const words = c.text.split(/\s+/);
  const total = words.reduce((s, w) => s + w.length + 1, 0);
  const prog = (t - c.start) / (c.end - c.start);
  // narration in cue spans nearly the whole duration; slight lead
  const pr = Math.min(1, prog * 1.04);
  let acc = 0;
  const lf = frame - Math.round(c.start * FPS);
  const op = interpolate(lf, [0, 5], [0, 1], clamp);
  const y = interpolate(lf, [0, 6], [14, 0], clamp);
  return (
    <div style={{position: 'absolute', left: 0, right: 0, bottom: 52, display: 'flex', justifyContent: 'center', opacity: op, transform: `translateY(${y}px)`}}>
      <div style={{maxWidth: 1560, background: 'rgba(8,8,10,0.84)', border: '4px solid #000', outline: '3px solid #ffd400', padding: '12px 34px 14px', textAlign: 'center', boxShadow: '8px 8px 0 rgba(0,0,0,0.7)'}}>
        <div style={{fontFamily: G.OSW, fontWeight: 600, fontSize: c.text.length > 150 ? 40 : 46, lineHeight: 1.22, letterSpacing: 1.2}}>
          {words.map((w, i) => {
            const startFrac = acc / total;
            acc += w.length + 1;
            const on = pr >= startFrac;
            return (
              <span key={i} style={{color: on ? '#fff' : 'rgba(255,255,255,0.38)'}}>{w}{' '}</span>
            );
          })}
        </div>
      </div>
    </div>
  );
};

const Overlay: React.FC = () => {
  const f = useCurrentFrame();
  const prog = f / TOTAL_FRAMES;
  return (
    <>
      <AbsoluteFill style={{pointerEvents: 'none', background: 'radial-gradient(ellipse at center, rgba(0,0,0,0) 55%, rgba(0,0,0,0.55) 100%)'}} />
      <AbsoluteFill style={{pointerEvents: 'none', opacity: 0.1, mixBlendMode: 'multiply', backgroundImage: 'radial-gradient(circle, #000 1.3px, transparent 1.7px)', backgroundSize: '10px 10px'}} />
      <AbsoluteFill style={{pointerEvents: 'none', boxShadow: 'inset 0 0 0 12px #050505, inset 0 0 0 15px rgba(255,255,255,0.85), inset 0 0 0 18px #050505'}} />
      <div style={{position: 'absolute', right: 40, top: 34, fontFamily: G.OSW, fontWeight: 700, fontSize: 26, letterSpacing: 6, color: 'rgba(255,255,255,0.8)', textShadow: '2px 2px 0 #000', background: 'rgba(0,0,0,0.45)', padding: '2px 14px'}}>PETER • EPS 1</div>
      <div style={{position: 'absolute', left: 18, right: 18, bottom: 18, height: 6, background: 'rgba(255,255,255,0.12)'}}>
        <div style={{width: `${prog * 100}%`, height: '100%', background: '#e10613'}} />
      </div>
    </>
  );
};

export const PeterVideo: React.FC = () => {
  const starts = sceneTimes.map((s) => Math.round(s.start * FPS));
  const sfxList: {from: number; name: string; vol: number}[] = [];
  SCENES.forEach((s, i) => {
    s.sfx.forEach(([t, name, vol]) => sfxList.push({from: Math.round(sceneTimes[i].start * FPS + t * FPS), name, vol}));
  });
  return (
    <AbsoluteFill style={{background: '#000'}}>
      {SCENES.map((s, i) => {
        const from = starts[i];
        const nextStart = i < SCENES.length - 1 ? starts[i + 1] : TOTAL_FRAMES;
        const baseLen = nextStart - from;
        const dur = i < SCENES.length - 1 ? baseLen + OVERLAP : baseLen;
        return (
          <Sequence key={i} from={from} durationInFrames={dur}>
            <SceneView sc={s} first={i === 0} baseLen={baseLen} />
          </Sequence>
        );
      })}
      <Overlay />
      <Subtitles />
      <Audio src={staticFile('audio/narration.mp3')} volume={1} />
      <Audio
        src={staticFile('audio/music.mp3')}
        volume={(fr) => 0.2 * interpolate(fr, [0, 45, TOTAL_FRAMES - 100, TOTAL_FRAMES - 5], [0, 1, 1, 0], clamp)}
      />
      {sfxList.map((s, i) => (
        <Sequence key={`sfx${i}`} from={s.from} durationInFrames={170}>
          <Audio src={staticFile(`sfx/${s.name}.mp3`)} volume={s.vol * 0.9} />
        </Sequence>
      ))}
    </AbsoluteFill>
  );
};
