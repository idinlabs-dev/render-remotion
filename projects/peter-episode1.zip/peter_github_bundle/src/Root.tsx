import React from 'react';
import {Composition} from 'remotion';
import {PeterVideo} from './Video';
import {TOTAL_FRAMES, FPS} from './scenes';

export const Root: React.FC = () => (
  <Composition id="Main" component={PeterVideo} durationInFrames={TOTAL_FRAMES} fps={FPS} width={1920} height={1080} />
);
