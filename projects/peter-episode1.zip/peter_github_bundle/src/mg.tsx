import React from 'react';
import {useCurrentFrame, useVideoConfig, interpolate, spring, Easing, random} from 'remotion';

export const BANG = "Bangers, Impact, sans-serif";
export const OSW = "Oswald, 'Arial Narrow', sans-serif";
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

const useSp = (delay = 0, damping = 9, stiffness = 200, mass = 0.55) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  return spring({frame: f - delay, fps, config: {damping, stiffness, mass}});
};

export const FadeWrap: React.FC<{children: React.ReactNode}> = ({children}) => {
  const f = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();
  const op = interpolate(f, [durationInFrames - 9, durationInFrames], [1, 0], clamp);
  return <div style={{position: 'absolute', inset: 0, opacity: op}}>{children}</div>;
};

const strokeText = (px: number, shadow = 6): React.CSSProperties => ({
  WebkitTextStroke: `${px}px #000`,
  paintOrder: 'stroke fill',
  textShadow: `${shadow}px ${shadow}px 0 #000`,
});

// ---------- Onomatopoeia ----------
const starPoints = (n: number, r1: number, r2: number, cx: number, cy: number, seed = 1) => {
  const pts: string[] = [];
  for (let i = 0; i < n * 2; i++) {
    const r = i % 2 === 0 ? r1 : r2 * (0.8 + 0.4 * random(`star${seed}-${i}`));
    const a = (Math.PI * i) / n;
    pts.push(`${cx + Math.cos(a) * r * 1.35},${cy + Math.sin(a) * r}`);
  }
  return pts.join(' ');
};

export const Onoma: React.FC<{text: string; x: number; y: number; rot?: number; color?: string; burst?: string; size?: number}> = ({
  text, x, y, rot = -8, color = '#fff', burst = '#e10613', size = 190,
}) => {
  const f = useCurrentFrame();
  const sp = useSp(0, 8, 220, 0.5);
  const shx = Math.sin(f * 2.1) * 4;
  const shy = Math.cos(f * 2.7) * 4;
  const W = size * 3.4, H = size * 2.4;
  return (
    <div style={{position: 'absolute', left: x, top: y, width: W, height: H, transform: `translate(-50%,-50%) translate(${shx}px,${shy}px) rotate(${rot}deg) scale(${sp})`}}>
      <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{position: 'absolute', inset: 0}}>
        <polygon points={starPoints(14, H * 0.46, H * 0.3, W / 2, H / 2, 3)} fill="#000" transform={`translate(10 10)`} />
        <polygon points={starPoints(14, H * 0.46, H * 0.3, W / 2, H / 2, 3)} fill={burst} stroke="#000" strokeWidth={8} strokeLinejoin="round" />
        <polygon points={starPoints(14, H * 0.34, H * 0.22, W / 2, H / 2, 7)} fill="#ffd400" opacity={0.9} />
      </svg>
      <div style={{position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: BANG, fontSize: size, color, letterSpacing: 4, ...strokeText(size / 18, size / 22)}}>{text}</div>
    </div>
  );
};

// ---------- Big title slam ----------
export const Slam: React.FC<{text: string; sub?: string; y?: number; size?: number; color?: string; bar?: string}> = ({text, sub, y = 330, size = 230, color = '#fff', bar = '#e10613'}) => {
  const f = useCurrentFrame();
  const sp = useSp(0, 12, 260, 0.6);
  const scale = 1 + (1 - sp) * 2.4;
  const op = interpolate(f, [0, 3], [0, 1], clamp);
  const shake = f < 9 ? Math.sin(f * 4) * (9 - f) * 1.6 : 0;
  const barW = interpolate(f, [2, 14], [0, 1], {...clamp, easing: Easing.out(Easing.cubic)});
  return (
    <div style={{position: 'absolute', left: 0, right: 0, top: y, textAlign: 'center', opacity: op, transform: `translate(${shake}px,${-shake}px)`}}>
      <div style={{position: 'absolute', left: '50%', top: size * 0.12, width: 1700 * barW, height: size * 0.78, background: bar, transform: 'translateX(-50%) skewX(-14deg)', border: '6px solid #000', boxShadow: '10px 10px 0 #000', opacity: 0.93}} />
      <div style={{position: 'relative', fontFamily: BANG, fontSize: size, lineHeight: 1.05, color, letterSpacing: 8, transform: `scale(${scale})`, ...strokeText(size / 20, size / 20)}}>{text}</div>
      {sub ? <div style={{position: 'relative', marginTop: 10, fontFamily: OSW, fontWeight: 700, fontSize: 54, color: '#ffd400', letterSpacing: 10, textShadow: '4px 4px 0 #000', opacity: interpolate(f, [8, 16], [0, 1], clamp)}}>{sub}</div> : null}
    </div>
  );
};

// ---------- Tag ----------
export const Tag: React.FC<{text: string; row?: number; color?: string; textColor?: string; right?: boolean}> = ({text, row = 0, color = '#ffd400', textColor = '#111', right = false}) => {
  const sp = useSp(0, 14, 170, 0.7);
  const tx = (1 - sp) * (right ? 700 : -700);
  return (
    <div style={{position: 'absolute', top: 64 + row * 104, [right ? 'right' : 'left']: 54, transform: `translateX(${tx}px)`}}>
      <div style={{position: 'relative', display: 'inline-block', padding: '10px 44px 8px 30px', background: color, border: '5px solid #000', boxShadow: '8px 8px 0 #000', transform: 'skewX(-10deg)'}}>
        <div style={{transform: 'skewX(10deg)', display: 'flex', alignItems: 'center', gap: 16}}>
          <div style={{width: 16, height: 46, background: '#e10613', border: '3px solid #000'}} />
          <div style={{fontFamily: OSW, fontWeight: 700, fontSize: 50, color: textColor, letterSpacing: 3, textTransform: 'uppercase', whiteSpace: 'nowrap'}}>{text}</div>
        </div>
      </div>
    </div>
  );
};

// ---------- NamePlate ----------
export const NamePlate: React.FC<{name: string; role: string; x?: number; y?: number}> = ({name, role, x = 90, y = 600}) => {
  const f = useCurrentFrame();
  const sp = useSp(0, 14, 160, 0.7);
  const line = interpolate(f, [4, 20], [0, 1], clamp);
  return (
    <div style={{position: 'absolute', left: x, top: y, transform: `translateX(${(1 - sp) * -600}px)`}}>
      <div style={{fontFamily: BANG, fontSize: 150, color: '#fff', letterSpacing: 6, lineHeight: 1, ...strokeText(8, 8)}}>{name}</div>
      <div style={{height: 10, width: 620 * line, background: '#e10613', border: '3px solid #000', marginTop: 4}} />
      <div style={{fontFamily: OSW, fontWeight: 700, fontSize: 44, color: '#ffd400', letterSpacing: 6, marginTop: 6, textShadow: '4px 4px 0 #000', textTransform: 'uppercase'}}>{role}</div>
    </div>
  );
};

// ---------- Counter ----------
const fmt = (n: number) => Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');
export const Counter: React.FC<{to: number; from?: number; prefix?: string; suffix?: string; label?: string; countDur?: number; y?: number; size?: number; color?: string; decimals?: number}> = ({
  to, from = 0, prefix = '', suffix = '', label, countDur = 2.8, y = 300, size = 150, color = '#ffd400', decimals = 0,
}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const sp = useSp(0, 14, 170, 0.7);
  const v = interpolate(f, [4, 4 + countDur * fps], [from, to], {...clamp, easing: Easing.out(Easing.cubic)});
  const txt = decimals ? v.toFixed(decimals).replace('.', ',') : fmt(v);
  const done = f > 4 + countDur * fps;
  const pulse = done ? 1 + Math.sin((f - 4 - countDur * fps) * 0.4) * 0.015 : 1;
  return (
    <div style={{position: 'absolute', left: 0, right: 0, top: y, textAlign: 'center', transform: `scale(${sp * pulse})`}}>
      {label ? <div style={{display: 'inline-block', fontFamily: OSW, fontWeight: 700, fontSize: 46, color: '#fff', background: '#e10613', border: '4px solid #000', padding: '4px 30px', letterSpacing: 6, boxShadow: '6px 6px 0 #000', transform: 'skewX(-10deg)'}}>{label}</div> : null}
      <div style={{fontFamily: BANG, fontSize: size, color, letterSpacing: 4, lineHeight: 1.1, marginTop: 6, ...strokeText(size / 16, size / 16)}}>{prefix}{txt}{suffix}</div>
    </div>
  );
};

// ---------- Crosshair ----------
export const Crosshair: React.FC<{x: number; y: number}> = ({x, y}) => {
  const f = useCurrentFrame();
  const r = interpolate(f, [0, 22], [300, 110], {...clamp, easing: Easing.out(Easing.cubic)});
  const rot = f * 3;
  const lock = f > 22 ? (Math.floor(f / 4) % 2 === 0 ? '#ff2b2b' : '#ffffff') : '#ff2b2b';
  return (
    <svg width={1920} height={1080} style={{position: 'absolute', inset: 0}}>
      <g transform={`translate(${x} ${y}) rotate(${rot})`} stroke={lock} fill="none" strokeWidth={7}>
        <circle r={r} />
        <circle r={r * 0.55} strokeWidth={4} />
        {[0, 90, 180, 270].map((a) => (
          <line key={a} x1={r + 28} y1={0} x2={r - 50} y2={0} transform={`rotate(${a})`} />
        ))}
      </g>
      <g transform={`translate(${x} ${y})`} stroke={lock} strokeWidth={5}>
        <line x1={-18} y1={0} x2={18} y2={0} />
        <line x1={0} y1={-18} x2={0} y2={18} />
      </g>
    </svg>
  );
};

// ---------- Map pins ----------
export const Pins: React.FC<{pts: {x: number; y: number; d: number}[]}> = ({pts}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  return (
    <svg width={1920} height={1080} style={{position: 'absolute', inset: 0}}>
      {pts.map((p, i) => {
        const s = spring({frame: f - p.d * fps, fps, config: {damping: 10, stiffness: 190, mass: 0.6}});
        const lf = Math.max(0, f - p.d * fps);
        const ring = (lf % 50) / 50;
        return (
          <g key={i} opacity={f >= p.d * fps ? 1 : 0}>
            <circle cx={p.x} cy={p.y} r={20 + ring * 90} fill="none" stroke="#ff2b2b" strokeWidth={6} opacity={1 - ring} />
            <g transform={`translate(${p.x} ${p.y - (1 - s) * 260}) scale(${1.2 * s})`}>
              <path d="M0 0 C-40 -50 -40 -100 0 -100 C40 -100 40 -50 0 0Z" fill="#e10613" stroke="#000" strokeWidth={6} />
              <circle cx={0} cy={-68} r={13} fill="#fff" stroke="#000" strokeWidth={4} />
            </g>
          </g>
        );
      })}
    </svg>
  );
};

// ---------- Rewind clock ----------
export const Clock: React.FC<{x: number; y: number; size?: number}> = ({x, y, size = 300}) => {
  const f = useCurrentFrame();
  const sp = useSp(0, 12, 170, 0.7);
  const min = -f * 22;
  const hr = -f * 22 / 12;
  const ticks = Array.from({length: 12});
  return (
    <svg width={1920} height={1080} style={{position: 'absolute', inset: 0}}>
      <g transform={`translate(${x} ${y}) scale(${sp})`}>
        <circle r={size / 2 + 22} fill="#000" opacity={0.55} />
        <circle r={size / 2} fill="#f6efd8" stroke="#000" strokeWidth={10} />
        {ticks.map((_, i) => (
          <line key={i} x1={0} y1={-size / 2 + 12} x2={0} y2={-size / 2 + 36} stroke="#000" strokeWidth={8} transform={`rotate(${i * 30})`} />
        ))}
        <line x1={0} y1={0} x2={0} y2={-size * 0.28} stroke="#000" strokeWidth={14} strokeLinecap="round" transform={`rotate(${hr})`} />
        <line x1={0} y1={0} x2={0} y2={-size * 0.4} stroke="#e10613" strokeWidth={9} strokeLinecap="round" transform={`rotate(${min})`} />
        <circle r={14} fill="#000" />
        <g transform={`rotate(${-f * 6})`} fill="none" stroke="#ffd400" strokeWidth={12}>
          <path d={`M ${size / 2 + 50} 0 A ${size / 2 + 50} ${size / 2 + 50} 0 1 0 0 ${-(size / 2 + 50)}`} />
          <polygon points={`0,${-(size / 2 + 80)} 0,${-(size / 2 + 20)} -46,${-(size / 2 + 50)}`} fill="#ffd400" stroke="#000" strokeWidth={4} />
        </g>
      </g>
    </svg>
  );
};

// ---------- ECG ----------
export const ECG: React.FC<{x: number; y: number; w?: number; bpm?: number; fast?: boolean; color?: string; label?: string}> = ({x, y, w = 640, bpm = 58, fast = false, color = '#39ff6a', label = 'DETAK JANTUNG'}) => {
  const f = useCurrentFrame();
  const sp = useSp(0, 16, 160, 0.8);
  const period = fast ? 70 : 120;
  const unit = (ox: number) => `L${ox + period * 0.35} 0 L${ox + period * 0.42} -20 L${ox + period * 0.47} 30 L${ox + period * 0.52} -110 L${ox + period * 0.58} 90 L${ox + period * 0.64} 0 L${ox + period * 0.78} -20 L${ox + period * 0.9} 0 L${ox + period} 0`;
  let d = 'M0 0';
  for (let i = 0; i < 24; i++) d += unit(i * period);
  const off = -(f * (fast ? 7 : 5));
  return (
    <div style={{position: 'absolute', left: x, top: y, width: w, transform: `scale(${sp})`, transformOrigin: 'left top'}}>
      <div style={{background: 'rgba(0,0,0,0.78)', border: '5px solid #000', outline: `3px solid ${color}`, padding: '14px 18px', boxShadow: '8px 8px 0 #000'}}>
        <div style={{display: 'flex', justifyContent: 'space-between', fontFamily: OSW, fontWeight: 700, fontSize: 32, color, letterSpacing: 4}}>
          <span>{label}</span>
          <span>{Math.round(bpm + Math.sin(f / 5) * 3)} BPM</span>
        </div>
        <div style={{overflow: 'hidden', width: w - 46, height: 180}}>
          <svg width={w - 46} height={180} viewBox={`0 -90 ${w - 46} 180`}>
            <path d={d} transform={`translate(${off} 0)`} stroke={color} strokeWidth={5} fill="none" strokeLinejoin="round" />
          </svg>
        </div>
      </div>
    </div>
  );
};

// ---------- Bell ----------
export const Bell: React.FC<{x: number; y: number}> = ({x, y}) => {
  const f = useCurrentFrame();
  const sp = useSp(0, 12, 170, 0.7);
  const ang = Math.sin(f * 0.55) * 26 * Math.exp(-f / 55);
  return (
    <svg width={1920} height={1080} style={{position: 'absolute', inset: 0}}>
      <g transform={`translate(${x} ${y}) scale(${sp * 1.5})`}>
        <rect x={-6} y={-70} width={12} height={40} fill="#444" />
        <g transform={`rotate(${ang})`}>
          <path d="M-52 52 C-52 10 -40 -26 0 -34 C40 -26 52 10 52 52 Z" fill="#ffc400" stroke="#000" strokeWidth={6} />
          <rect x={-62} y={50} width={124} height={14} rx={7} fill="#e6a800" stroke="#000" strokeWidth={5} />
          <circle cx={0} cy={78} r={12} fill="#ffc400" stroke="#000" strokeWidth={5} />
        </g>
        {[-1, 1].map((s) => (
          <g key={s} stroke="#fff" strokeWidth={6} strokeLinecap="round" opacity={0.9 * Math.exp(-f / 70)}>
            <line x1={s * 82} y1={0} x2={s * 112} y2={-12} />
            <line x1={s * 88} y1={26} x2={s * 124} y2={26} />
          </g>
        ))}
      </g>
    </svg>
  );
};

// ---------- Knife fly ----------
export const KnifeFly: React.FC<{y?: number}> = ({y = 500}) => {
  const f = useCurrentFrame();
  const t = interpolate(f, [0, 14], [0, 1], {...clamp, easing: Easing.out(Easing.cubic)});
  const x = interpolate(t, [0, 1], [2300, 1280]);
  const yy = y + (1 - t) * -200;
  const rot = interpolate(t, [0, 1], [-30, -90]);
  return (
    <svg width={1920} height={1080} style={{position: 'absolute', inset: 0}}>
      <g opacity={0.8 * (1 - t)}>
        {[0, 1, 2].map((i) => (
          <line key={i} x1={x + 60 + i * 60} y1={yy - 40 + i * 16} x2={x + 400 + i * 200} y2={yy - 220 + i * 40} stroke="#fff" strokeWidth={5} />
        ))}
      </g>
      <g transform={`translate(${x} ${yy}) rotate(${rot}) scale(1.3)`}>
        <polygon points="0,-15 230,-4 250,0 230,6 0,15" fill="#e8eef2" stroke="#000" strokeWidth={6} strokeLinejoin="round" />
        <polygon points="0,-6 220,-1 220,1 0,6" fill="#9aa8b3" />
        <rect x={-30} y={-22} width={34} height={44} fill="#e10613" stroke="#000" strokeWidth={6} />
        <rect x={-140} y={-17} width={112} height={34} rx={8} fill="#222" stroke="#000" strokeWidth={6} />
      </g>
    </svg>
  );
};

// ---------- Alert triangle ----------
export const Alert: React.FC<{x: number; y: number; text?: string}> = ({x, y, text}) => {
  const f = useCurrentFrame();
  const sp = useSp(0, 8, 200, 0.6);
  const pulse = 1 + Math.sin(f * 0.6) * 0.06;
  const blink = Math.floor(f / 6) % 2 === 0;
  return (
    <div style={{position: 'absolute', left: x, top: y, transform: `translate(-50%,-50%) scale(${sp * pulse})`, textAlign: 'center'}}>
      <svg width={260} height={230} viewBox="0 0 260 230">
        <polygon points="130,14 246,214 14,214" fill={blink ? '#ffd400' : '#ff3b30'} stroke="#000" strokeWidth={10} strokeLinejoin="round" />
        <text x={130} y={186} textAnchor="middle" fontFamily={BANG} fontSize={170} fill="#000">!</text>
      </svg>
      {text ? <div style={{fontFamily: BANG, fontSize: 70, color: '#fff', letterSpacing: 4, marginTop: -6, ...strokeText(6, 5)}}>{text}</div> : null}
    </div>
  );
};

// ---------- Rule card ----------
export const RuleCard: React.FC<{title: string; a: string; b: string}> = ({title, a, b}) => {
  const f = useCurrentFrame();
  const sp = useSp(0, 13, 170, 0.7);
  const bShow = interpolate(f, [26, 34], [0, 1], clamp);
  return (
    <div style={{position: 'absolute', left: 0, right: 0, top: 250, display: 'flex', justifyContent: 'center', transform: `scale(${sp}) rotate(${(1 - sp) * -8}deg)`}}>
      <div style={{width: 1200, background: 'rgba(8,8,8,0.9)', border: '8px solid #ffd400', boxShadow: '14px 14px 0 #000', padding: '26px 40px', textAlign: 'center'}}>
        <div style={{fontFamily: OSW, fontWeight: 700, fontSize: 40, color: '#ffd400', letterSpacing: 10}}>{title}</div>
        <div style={{fontFamily: BANG, fontSize: 110, color: '#fff', letterSpacing: 4, lineHeight: 1.1, marginTop: 8, ...strokeText(5, 5)}}>{a}</div>
        <div style={{fontFamily: BANG, fontSize: 40, color: '#ffd400', opacity: bShow}}>▼</div>
        <div style={{fontFamily: BANG, fontSize: 112, color: '#ff3b30', letterSpacing: 4, lineHeight: 1.1, opacity: bShow, transform: `scale(${1 + (1 - bShow) * 0.4})`, ...strokeText(5, 5)}}>{b}</div>
      </div>
    </div>
  );
};

// ---------- Bars ----------
export const Bars: React.FC<{title: string; items: {l: string; v: number}[]}> = ({title, items}) => {
  const f = useCurrentFrame();
  const sp = useSp(0, 14, 160, 0.7);
  return (
    <div style={{position: 'absolute', right: 70, top: 120, width: 760, transform: `translateX(${(1 - sp) * 900}px)`}}>
      <div style={{background: 'rgba(0,0,0,0.82)', border: '6px solid #000', outline: '4px solid #ffd400', padding: '20px 26px', boxShadow: '10px 10px 0 #000'}}>
        <div style={{fontFamily: OSW, fontWeight: 700, fontSize: 38, color: '#ffd400', letterSpacing: 5, marginBottom: 14}}>{title}</div>
        {items.map((it, i) => {
          const w = interpolate(f, [14 + i * 14, 40 + i * 14], [0, it.v], {...clamp, easing: Easing.out(Easing.cubic)});
          return (
            <div key={i} style={{marginBottom: 14}}>
              <div style={{fontFamily: OSW, fontWeight: 600, fontSize: 32, color: '#fff', letterSpacing: 3}}>{it.l}</div>
              <div style={{height: 28, background: '#2a2a2a', border: '3px solid #000'}}>
                <div style={{height: '100%', width: `${w}%`, background: `linear-gradient(90deg,#ff3b30,#ffd400)`}} />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

// ---------- Meter ----------
export const Meter: React.FC<{label: string; from: number; to: number; y?: number; x?: number; color?: string; w?: number; dur?: number; unit?: string}> = ({label, from, to, y = 690, x = 520, color = '#ff3b30', w = 880, dur = 3, unit = '%'}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const sp = useSp(0, 14, 170, 0.7);
  const v = interpolate(f, [6, 6 + dur * fps], [from, to], {...clamp, easing: Easing.inOut(Easing.cubic)});
  return (
    <div style={{position: 'absolute', left: x, top: y, width: w, transform: `scale(${sp})`, transformOrigin: 'left center'}}>
      <div style={{display: 'flex', justifyContent: 'space-between', fontFamily: OSW, fontWeight: 700, fontSize: 44, color: '#fff', letterSpacing: 6, textShadow: '4px 4px 0 #000'}}>
        <span>{label}</span><span style={{color}}>{Math.round(v)}{unit}</span>
      </div>
      <div style={{height: 46, background: '#1b1b1b', border: '6px solid #000', outline: '3px solid #fff', boxShadow: '8px 8px 0 #000'}}>
        <div style={{height: '100%', width: `${v}%`, background: `repeating-linear-gradient(115deg, ${color} 0 24px, rgba(255,255,255,0.35) 24px 30px)`}} />
      </div>
    </div>
  );
};

// ---------- Stamp ----------
export const Stamp: React.FC<{text: string; x: number; y: number; rot?: number; color?: string; size?: number}> = ({text, x, y, rot = -10, color = '#ff2b2b', size = 120}) => {
  const f = useCurrentFrame();
  const sp = useSp(0, 14, 260, 0.6);
  const sc = 1 + (1 - sp) * 2.6;
  const op = interpolate(f, [0, 3], [0, 1], clamp);
  return (
    <div style={{position: 'absolute', left: x, top: y, transform: `translate(-50%,-50%) rotate(${rot}deg) scale(${sc})`, opacity: op}}>
      <div style={{border: `14px solid ${color}`, color, fontFamily: BANG, fontSize: size, letterSpacing: 8, padding: '0 36px', background: 'rgba(0,0,0,0.55)', textShadow: '5px 5px 0 #000', boxShadow: '8px 8px 0 #000', whiteSpace: 'nowrap'}}>{text}</div>
    </div>
  );
};

// ---------- Quote card ----------
export const Quote: React.FC<{text: string; y?: number; size?: number}> = ({text, y = 90, size = 84}) => {
  const f = useCurrentFrame();
  const sp = useSp(0, 14, 160, 0.7);
  return (
    <div style={{position: 'absolute', left: 0, right: 0, top: y, display: 'flex', justifyContent: 'center', transform: `translateY(${(1 - sp) * -200}px)`, opacity: interpolate(f, [0, 5], [0, 1], clamp)}}>
      <div style={{maxWidth: 1500, background: 'rgba(255,248,220,0.96)', border: '7px solid #000', boxShadow: '12px 12px 0 #000', padding: '18px 44px', textAlign: 'center', borderRadius: 18}}>
        <div style={{fontFamily: BANG, fontSize: size, color: '#111', letterSpacing: 3, lineHeight: 1.12}}>{text}</div>
      </div>
    </div>
  );
};

// ---------- Speed lines ----------
export const SpeedLines: React.FC<{color?: string; inner?: number}> = ({color = '#ffffff', inner = 520}) => {
  const f = useCurrentFrame();
  const step = Math.floor(f / 2);
  const lines = Array.from({length: 64});
  return (
    <svg width={1920} height={1080} style={{position: 'absolute', inset: 0, opacity: 0.75}}>
      {lines.map((_, i) => {
        const a = (i / 64) * Math.PI * 2 + random(`a${step}-${i}`) * 0.06;
        const r1 = inner + random(`r${step}-${i}`) * 260;
        const half = 0.012 + random(`w${step}-${i}`) * 0.02;
        const R = 1300;
        const p = (rr: number, aa: number) => `${960 + Math.cos(aa) * rr},${540 + Math.sin(aa) * rr}`;
        return <polygon key={i} points={`${p(r1, a)} ${p(R, a - half)} ${p(R, a + half)}`} fill={color} />;
      })}
    </svg>
  );
};

// ---------- Flash ----------
export const Flash: React.FC<{color?: string; len?: number}> = ({color = '#fff', len = 12}) => {
  const f = useCurrentFrame();
  return <div style={{position: 'absolute', inset: 0, background: color, opacity: interpolate(f, [0, len], [1, 0], clamp)}} />;
};

// ---------- Smoke ----------
export const Smoke: React.FC<{x: number; y: number}> = ({x, y}) => {
  const f = useCurrentFrame();
  const circles = Array.from({length: 16});
  return (
    <div style={{position: 'absolute', inset: 0}}>
      {circles.map((_, i) => {
        const ang = random(`sm${i}`) * Math.PI * 2;
        const dist = interpolate(f, [0, 40], [0, 200 + random(`sd${i}`) * 700], {...clamp, easing: Easing.out(Easing.cubic)});
        const s = interpolate(f, [0, 40], [0.4, 1.6 + random(`ss${i}`)], clamp);
        const size = 420;
        const op = interpolate(f, [0, 6, 70, 100], [0, 0.9, 0.8, 0], clamp);
        return <div key={i} style={{position: 'absolute', left: x + Math.cos(ang) * dist - size / 2, top: y + Math.sin(ang) * dist * 0.7 - size / 2, width: size, height: size, borderRadius: '50%', background: 'radial-gradient(circle, rgba(255,255,255,0.97) 0%, rgba(235,235,240,0.75) 45%, rgba(255,255,255,0) 72%)', transform: `scale(${s})`, opacity: op}} />;
      })}
    </div>
  );
};

// ---------- Coins ----------
export const Coins: React.FC<{count?: number}> = ({count = 16}) => {
  const f = useCurrentFrame();
  return (
    <svg width={1920} height={1080} style={{position: 'absolute', inset: 0}}>
      {Array.from({length: count}).map((_, i) => {
        const x = 100 + random(`cx${i}`) * 1720;
        const speed = 5 + random(`cs${i}`) * 5;
        const y0 = -random(`cy${i}`) * 900;
        const y = ((y0 + f * speed) % 1300) - 150;
        const rot = f * (3 + random(`cr${i}`) * 6);
        const sx = Math.abs(Math.cos((rot * Math.PI) / 180));
        return (
          <g key={i} transform={`translate(${x} ${y}) scale(${Math.max(0.15, sx)} 1)`}>
            <circle r={40} fill="#ffc400" stroke="#000" strokeWidth={6} />
            <circle r={29} fill="none" stroke="#b37d00" strokeWidth={4} />
            <text y={16} textAnchor="middle" fontFamily={BANG} fontSize={46} fill="#7a5200">$</text>
          </g>
        );
      })}
    </svg>
  );
};

// ---------- Shock ring ----------
export const ShockRing: React.FC<{x: number; y: number}> = ({x, y}) => {
  const f = useCurrentFrame();
  const r = interpolate(f, [0, 24], [20, 520], {...clamp, easing: Easing.out(Easing.cubic)});
  const op = interpolate(f, [0, 24], [1, 0], clamp);
  return (
    <svg width={1920} height={1080} style={{position: 'absolute', inset: 0}}>
      <circle cx={x} cy={y} r={r} fill="none" stroke="#fff" strokeWidth={22 * op + 2} opacity={op} />
      <circle cx={x} cy={y} r={r * 0.62} fill="none" stroke="#ffd400" strokeWidth={12 * op + 1} opacity={op} />
    </svg>
  );
};

// ---------- Dark fade ----------
export const BlackFade: React.FC = () => {
  const f = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();
  return <div style={{position: 'absolute', inset: 0, background: '#000', opacity: interpolate(f, [0, durationInFrames - 2], [0, 1], clamp)}} />;
};
