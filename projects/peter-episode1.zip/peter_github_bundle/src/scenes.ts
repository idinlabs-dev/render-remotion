import cues from './cues.json';

export type MG = {k: string; at: number; dur: number; p?: any};
export type Scene = {
  c: [number, number]; // cue index range (1-based, inclusive)
  img: string;
  cam: 'in' | 'out' | 'left' | 'right' | 'up' | 'down';
  amt?: number;
  tone?: 'sepia' | 'cold' | 'dim' | 'warm';
  shake?: [number, number, number][]; // from,to,amp (sec relative)
  speed?: [number, number, string?][];
  flash?: [number, string?][];
  black?: number; // fade to black seconds at end
  sfx: [number, string, number][]; // t, name, vol
  mg: MG[];
};

const m = (k: string, at: number, dur: number, p: any = {}): MG => ({k, at, dur, p});
const tag = (at: number, dur: number, text: string, row = 0, extra: any = {}) => m('tag', at, dur, {text, row, ...extra});
const onoma = (at: number, dur: number, text: string, x: number, y: number, extra: any = {}) => m('onoma', at, dur, {text, x, y, ...extra});

export const SCENES: Scene[] = [
  // 1
  {c: [1, 1], img: 'p01', cam: 'in', sfx: [[0, 'rumble', 0.55], [0.5, 'blip', 0.5], [1.2, 'blip', 0.5], [1.9, 'blip', 0.5], [2.6, 'blip', 0.5], [3.1, 'riser', 0.35]], mg: [
    tag(0.3, 4.3, 'Organisasi Bersenjata'),
    m('pins', 0.5, 4.3, {pts: [{x: 420, y: 520, d: 0}, {x: 860, y: 430, d: 0.7}, {x: 1280, y: 560, d: 1.4}, {x: 1560, y: 380, d: 2.1}, {x: 1000, y: 700, d: 2.8}]}),
    m('cross', 3.2, 1.7, {x: 960, y: 520}),
  ]},
  // 2
  {c: [2, 2], img: 'p02', cam: 'out', shake: [[3.4, 4.8, 8]], sfx: [[0.3, 'heartbeat', 0.6], [3.35, 'whoosh', 0.7], [3.5, 'impact', 0.95]], flash: [[3.5, '#fff']], mg: [
    tag(0.3, 3, 'Mereka Semua Takut'),
    m('slam', 3.5, 1.45, {text: 'PETER', y: 330, size: 300}),
  ]},
  // 3
  {c: [3, 3], img: 'p03', cam: 'right', tone: 'cold', sfx: [[0.1, 'whoosh', 0.6], [0.4, 'steps', 0.65], [3.5, 'rumble', 0.4]], mg: [
    tag(0.4, 3.2, 'Adegan Masa Depan'),
    tag(3.8, 2.3, 'Peter Bertopeng', 0),
  ]},
  // 4
  {c: [4, 4], img: 'p04', cam: 'in', sfx: [[0.3, 'blip', 0.5], [1.4, 'blip', 0.6], [2.4, 'blip', 0.6]], mg: [
    tag(0.3, 5, 'Musuh Kebingungan'),
    onoma(1.2, 2.0, '?!', 330, 400, {size: 150, rot: -12, burst: '#1b6bff'}),
    onoma(2.4, 2.0, '?!', 1560, 430, {size: 150, rot: 10, burst: '#1b6bff'}),
  ]},
  // 5
  {c: [5, 5], img: 'p05', cam: 'in', shake: [[5.7, 6.5, 6]], sfx: [[0.6, 'mask', 0.9], [2.3, 'riser', 0.4], [4.8, 'whoosh', 0.8], [5.5, 'impact', 0.9]], flash: [[5.5, '#fff']], mg: [
    tag(0.4, 3.5, 'Topeng Dibuka'),
    onoma(2.8, 2.0, 'MERINDING!', 960, 400, {size: 130, rot: -5}),
    m('clock', 4.8, 4.0, {x: 1500, y: 360}),
    m('slam', 5.5, 3.3, {text: '3 BULAN LALU', sub: 'MUNDUR KE BELAKANG', y: 480, size: 190}),
  ]},
  // 6
  {c: [6, 6], img: 'p06', cam: 'left', tone: 'warm', sfx: [[2.7, 'whoosh', 0.6], [2.9, 'impact', 0.55], [6.0, 'blip', 0.6], [8.4, 'blip', 0.6]], mg: [
    m('slam', 2.9, 3.4, {text: 'GLORY CLUB', sub: 'ORGANISASI KRIMINAL', y: 120, size: 150}),
    tag(6.0, 3.5, 'Pensiun Jadi Legenda'),
    tag(8.5, 2.8, 'Toko Buku Bekas', 1),
  ]},
  // 7
  {c: [7, 7], img: 'p07', cam: 'in', tone: 'cold', sfx: [[0.3, 'cough', 0.9], [1.2, 'heartbeat', 0.7], [3.3, 'impact', 0.8]], mg: [
    m('ecg', 0.6, 5.2, {x: 90, y: 90, bpm: 54, label: 'USIA 60-AN'}),
    m('stamp', 3.3, 2.4, {text: 'KANKER', x: 1450, y: 330, rot: -8}),
    m('counter', 4.1, 1.9, {to: 3, suffix: ' BULAN', label: 'SISA UMUR', y: 520, size: 130, countDur: 0.6, color: '#ff3b30'}),
  ]},
  // 8
  {c: [8, 8], img: 'p08', cam: 'in', sfx: [[0.15, 'shopbell', 0.9], [1.0, 'blip', 0.4]], mg: [
    m('bell', 0.2, 3.2, {x: 1560, y: 230}),
    onoma(0.5, 2.0, 'KRING!', 1250, 520, {size: 150, rot: 8, burst: '#ffb400', color: '#fff'}),
    tag(2.4, 4, 'Siang Itu, Seorang Pelanggan'),
  ]},
  // 9
  {c: [9, 9], img: 'p09', cam: 'right', tone: 'warm', sfx: [[2.4, 'blip', 0.5], [4.2, 'blip', 0.5]], mg: [
    tag(2.4, 3.3, 'Buku Dari Seluruh Dunia'),
    tag(4.3, 2.0, 'Untuk Adiknya', 1),
  ]},
  // 10
  {c: [10, 10], img: 'p10', cam: 'out', sfx: [[2.2, 'impact', 0.5], [5.0, 'blip', 0.5]], mg: [
    m('stamp', 2.3, 2.6, {text: 'GRATIS!', x: 1450, y: 300, rot: 8, color: '#35e06a', size: 140}),
    tag(5.1, 2.8, 'Ditolak: Kebanyakan Om'),
  ]},
  // 11
  {c: [11, 11], img: 'p11', cam: 'in', tone: 'cold', sfx: [[3.4, 'riser', 0.55], [4.3, 'heartbeat', 0.6]], mg: [
    tag(3.7, 4, 'Suasana Berubah'),
    m('alert', 5.2, 2.6, {x: 1560, y: 330, text: ''}),
  ]},
  // 12
  {c: [12, 12], img: 'p12', cam: 'in', shake: [[8.0, 9.2, 10]], speed: [[8.0, 9.5, '#ff2b2b']], flash: [[8.0, '#ff2b2b']], sfx: [[3.5, 'riser', 0.5], [4.6, 'heartbeat', 0.75], [7.85, 'knife', 1], [8.1, 'impact', 0.7]], mg: [
    tag(4.8, 4, 'Hawa Membunuh'),
    m('alert', 6.4, 2.6, {x: 1560, y: 330}),
    m('knife', 7.9, 1.8, {y: 560}),
  ]},
  // 13
  {c: [13, 13], img: 'p13', cam: 'in', tone: 'cold', sfx: [[0.4, 'blip', 0.6], [3.7, 'blip', 0.6]], mg: [
    m('quote', 0.4, 3.2, {text: 'JANGAN LAKUKAN HAL YANG BAKAL KAMU SESALI', y: 80, size: 70}),
    m('quote', 3.8, 3.4, {text: 'KALAU KAMU NURUT, OM TIDAK AKAN BUNUH KAMU', y: 80, size: 70}),
  ]},
  // 14
  {c: [14, 14], img: 'p14', cam: 'in', shake: [[0.3, 1.0, 8]], sfx: [[0.3, 'impact', 0.6], [0.35, 'whoosh', 0.5], [3.6, 'blip', 0.5]], mg: [
    onoma(0.4, 2.2, '!!', 1520, 360, {size: 240, rot: 8}),
    tag(3.6, 3.8, 'Gerak-Geriknya Sudah Ketahuan'),
  ]},
  // 15
  {c: [15, 15], img: 'p15', cam: 'in', shake: [[4.6, 9.4, 4]], speed: [[0.4, 2.6, '#ffffff'], [4.6, 7.0, '#7b2cff']], sfx: [[0.9, 'slash', 0.8], [4.5, 'rumble', 0.7], [4.6, 'impact', 0.8], [6.0, 'heartbeat', 0.7]], mg: [
    m('slam', 4.6, 3.6, {text: 'AURA MEMATIKAN', y: 110, size: 150}),
    onoma(7.4, 1.9, 'GEMETAR...', 1460, 640, {size: 100, rot: 6, burst: '#7b2cff'}),
  ]},
  // 16
  {c: [16, 16], img: 'p16', cam: 'right', tone: 'warm', sfx: [[1.8, 'blip', 0.4], [5.2, 'blip', 0.6]], mg: [
    tag(1.8, 3, 'Om Tahu Kamu Tidak Bohong'),
    tag(5.2, 3, 'Panti Asuhan Yongguang'),
  ]},
  // 17
  {c: [17, 17], img: 'p17', cam: 'out', tone: 'cold', sfx: [[1.4, 'riser', 0.5], [3.4, 'impact', 0.6]], mg: [
    tag(2.7, 2.7, 'Kalau Misi Gagal?'),
  ]},
  // 18
  {c: [18, 18], img: 'p18', cam: 'in', shake: [[0.3, 1.5, 14]], flash: [[0.3, '#fff']], sfx: [[0.3, 'doorkick', 1], [0.4, 'impact', 0.7]], mg: [
    onoma(0.35, 2.4, 'BRAAK!', 960, 430, {size: 260, rot: -6}),
    tag(2.4, 3.2, 'Dua Pembunuh Masuk'),
  ]},
  // 19
  {c: [19, 19], img: 'p19', cam: 'in', tone: 'dim', sfx: [[0.25, 'whoosh', 0.7], [0.35, 'impact', 0.8], [2.0, 'riser', 0.4]], mg: [
    m('rule', 0.3, 4.2, {title: 'ATURAN GLORY CLUB', a: 'MISI GAGAL', b: 'PEMBUNUH + TARGET DIBUNUH'}),
  ]},
  // 20
  {c: [20, 20], img: 'p20', cam: 'in', shake: [[0.9, 1.4, 8], [2.9, 3.3, 8], [6.0, 6.4, 8], [7.9, 8.3, 8], [9.9, 10.5, 10]], sfx: [[0.9, 'punch', 0.9], [2.9, 'punch', 0.9], [6.0, 'punch', 0.8], [7.9, 'punch', 0.8], [9.8, 'thud', 1], [12.0, 'blip', 0.4]], mg: [
    onoma(0.95, 1.5, 'BUGH!', 560, 400, {size: 170, rot: -10}),
    onoma(2.95, 1.5, 'PLAK!', 1400, 380, {size: 170, rot: 8}),
    m('meter', 4.4, 8.5, {label: 'STAMINA PETER', from: 100, to: 12, y: 150, x: 1000, w: 820, dur: 7, color: '#ff9f1a'}),
    tag(5.0, 4, 'Umur Tidak Bisa Bohong'),
    onoma(9.9, 1.7, 'BRUK!', 1500, 700, {size: 160, rot: 6, burst: '#ffb400'}),
    tag(11.8, 3, 'Killer Legendaris Selemah Ini?', 0, {color: '#ff3b30', textColor: '#fff'}),
  ]},
  // 21
  {c: [21, 21], img: 'p21', cam: 'in', tone: 'dim', sfx: [[0.1, 'steps', 0.5], [1.8, 'impact', 0.8], [1.9, 'rumble', 0.5], [6.2, 'blip', 0.6]], mg: [
    m('name', 1.8, 4.5, {name: 'OKTOMEN', role: 'Bos Pemburu Peter', x: 90, y: 560}),
    tag(6.4, 3.4, 'Tak Bisa Kalahkan Kanker', 0, {color: '#ff3b30', textColor: '#fff'}),
  ]},
  // 22
  {c: [22, 22], img: 'p22', cam: 'in', tone: 'cold', sfx: [[0.5, 'blip', 0.5], [3.8, 'riser', 0.5], [5.9, 'cash', 1], [5.95, 'impact', 0.7]], flash: [[5.9, '#ffd400']], mg: [
    tag(0.5, 4.2, 'Kenapa Mengincar Peter?'),
    m('slam', 5.9, 2.2, {text: 'UANG', y: 340, size: 300, bar: '#1fa34a'}),
  ]},
  // 23+24
  {c: [23, 24], img: 'p23', cam: 'in', amt: 0.18, sfx: [[0.9, 'cash', 0.9], [3.8, 'cash', 0.8], [5.7, 'cash', 0.9], [9.6, 'impact', 0.9], [13.4, 'impact', 0.9], [13.3, 'riser', 0.4]], mg: [
    m('coins', 0, 16.2, {count: 14}),
    m('counter', 0.8, 5.5, {to: 7600000000, prefix: '₩', label: 'BOUNTY DI KEPALA PETER', y: 270, size: 150, countDur: 3, color: '#ffd400'}),
    m('counter', 5.8, 3.4, {to: 7.6, prefix: '≈ US$ ', suffix: ' JUTA', y: 300, size: 140, countDur: 1.2, decimals: 1, color: '#35e06a'}),
    m('stamp', 9.6, 3.2, {text: 'SALDO REKENING PETER', x: 960, y: 330, rot: -4, color: '#ffd400', size: 100}),
    m('stamp', 13.4, 2.8, {text: 'MENDING MATI', x: 960, y: 330, rot: -6, color: '#ff2b2b', size: 150}),
  ]},
  // 25
  {c: [25, 25], img: 'p24', cam: 'in', shake: [[1.5, 1.9, 12], [3.0, 3.4, 12], [4.3, 4.8, 14]], flash: [[1.5, '#fff'], [3.0, '#fff'], [4.3, '#fff']], sfx: [[1.5, 'punch', 1], [3.0, 'punch', 1], [4.3, 'punch', 1], [5.2, 'thud', 0.9]], mg: [
    onoma(1.55, 1.3, 'BAKK!', 520, 400, {size: 190, rot: -8}),
    onoma(3.05, 1.3, 'BUGH!', 1450, 420, {size: 190, rot: 8}),
    onoma(4.35, 1.8, 'DUAKK!', 960, 330, {size: 220, rot: -3}),
    m('meter', 0.6, 5.5, {label: 'NYAWA PETER', from: 45, to: 4, y: 880, x: 90, w: 700, dur: 4.5, color: '#ff2b2b'}),
  ]},
  // 26
  {c: [26, 26], img: 'p25', cam: 'in', tone: 'dim', shake: [[4.2, 5.5, 14]], flash: [[4.2, '#fff']], sfx: [[1.0, 'riser', 0.55], [4.15, 'flare', 1], [6.8, 'whoosh', 0.5]], mg: [
    m('smoke', 4.2, 4.1, {x: 960, y: 560}),
    onoma(4.25, 2.2, 'DOOOR!', 960, 330, {size: 260, rot: -4, burst: '#ff7a00'}),
    tag(6.0, 2.2, 'Flare Bomb'),
    tag(6.9, 1.4, 'Kabur!', 1, {color: '#ff3b30', textColor: '#fff'}),
  ]},
  // 27
  {c: [27, 27], img: 'p26', cam: 'left', tone: 'cold', sfx: [[0.1, 'run', 0.8], [5.0, 'heartbeat', 0.9], [5.1, 'impact', 0.6]], mg: [
    tag(0.3, 3.5, 'Taman, Tengah Malam'),
    m('ecg', 1.2, 4.5, {x: 1180, y: 700, bpm: 142, fast: true, color: '#ff3b30', label: 'DETAK JANTUNG'}),
    onoma(2.6, 1.8, 'HAH... HAH...', 600, 330, {size: 120, rot: -6, burst: '#1b6bff'}),
    m('slam', 5.0, 2.4, {text: 'SEKARAT', y: 110, size: 200, bar: '#7a0000'}),
  ]},
  // 28
  {c: [28, 28], img: 'p27', cam: 'in', tone: 'sepia', sfx: [[0.1, 'whoosh', 0.6], [2.0, 'blip', 0.5]], mg: [
    tag(0.3, 3.2, 'Flashback'),
    tag(2.0, 3.4, 'Seluruh Hidupnya', 1),
  ]},
  // 29
  {c: [29, 29], img: 'p28', cam: 'in', tone: 'dim', sfx: [[0.8, 'riser', 0.5], [3.8, 'impact', 1]], flash: [[3.8, '#ff2b2b']], mg: [
    tag(1.8, 2.2, 'Bos Baru Datang'),
    m('stamp', 3.8, 2.4, {text: 'DIKHIANATI', x: 960, y: 420, rot: -7, size: 170}),
  ]},
  // 30
  {c: [30, 30], img: 'p29', cam: 'up', tone: 'cold', black: 1.2, sfx: [[0.2, 'heartbeat', 0.8], [4.5, 'heartbeat', 0.8], [6.8, 'rumble', 0.6]], mg: [
    tag(0.4, 3.5, 'Ingatan Terakhir'),
    tag(5.0, 4, 'Gadis Kecil Yang Dibawa Pergi'),
  ]},
  // 31
  {c: [31, 31], img: 'p30', cam: 'in', tone: 'warm', sfx: [[0, 'kitchen', 0.7], [3.0, 'blip', 0.4]], mg: [
    tag(0.5, 3.5, 'Markas Oktomen'),
    tag(1.4, 3.5, 'Dua Pembunuh Gagal', 1),
    onoma(3.2, 2.5, 'NGEDUMEL...', 1500, 330, {size: 100, rot: 6, burst: '#ffb400', color: '#fff'}),
  ]},
  // 32
  {c: [32, 32], img: 'p31', cam: 'in', tone: 'cold', sfx: [[0, 'kitchen', 0.45], [5.5, 'riser', 0.6], [7.2, 'impact', 0.7]], mg: [
    onoma(1.0, 3.0, 'KAYA RAYA!', 960, 340, {size: 150, rot: -5, burst: '#35e06a'}),
    m('alert', 7.2, 1.9, {x: 1560, y: 330}),
    tag(7.1, 2.0, 'Suara Cowok Muda'),
  ]},
  // 33
  {c: [33, 33], img: 'p32', cam: 'in', flash: [[1.0, '#fff']], sfx: [[1.0, 'shutter', 1]], mg: [
    tag(0.5, 4, 'Foto Pertama Buatannya'),
  ]},
  // 34
  {c: [34, 34], img: 'p33', cam: 'out', sfx: [[0.5, 'whoosh', 0.7], [0.6, 'impact', 0.7], [3.4, 'blip', 0.6], [6.2, 'blip', 0.6], [8.4, 'impact', 0.8]], mg: [
    tag(3.4, 2.6, 'Tinggi, Rambut Hitam'),
    tag(6.2, 2.6, 'Mata Merah Tajam'),
    m('stamp', 8.4, 2.2, {text: 'BAJU SAMA PERSIS', x: 960, y: 330, rot: -4, size: 120}),
  ]},
  // 35
  {c: [35, 35], img: 'p34', cam: 'in', sfx: [[2.8, 'whoosh', 0.6], [2.9, 'impact', 1]], flash: [[2.9, '#ff2b2b']], shake: [[2.9, 3.6, 9]], mg: [
    tag(0.3, 2.3, 'Dia Tersenyum Tipis'),
    m('slam', 2.9, 2.5, {text: 'GUE PETER', y: 130, size: 230}),
  ]},
  // 36
  {c: [36, 36], img: 'p35', cam: 'in', speed: [[0.2, 1.6, '#ffffff']], shake: [[2.9, 3.5, 12]], sfx: [[0.9, 'whoosh', 0.8], [2.9, 'punch', 1], [2.95, 'impact', 0.6]], mg: [
    onoma(1.0, 1.5, 'WUUSH!', 560, 380, {size: 170, rot: -8, burst: '#1b6bff'}),
    m('shock', 2.9, 1.2, {x: 1050, y: 520}),
    onoma(3.0, 2.8, 'TAP!', 1300, 330, {size: 230, rot: 6}),
    tag(3.9, 2.4, 'Semudah Menangkap Lalat'),
  ]},
  // 37
  {c: [37, 37], img: 'p36', cam: 'right', shake: [[2.6, 3.0, 10]], sfx: [[1.3, 'whoosh', 0.8], [2.6, 'thud', 1]], mg: [
    onoma(1.4, 1.4, 'SYAT!', 560, 380, {size: 170, rot: -8, burst: '#1b6bff'}),
    m('slam', 2.7, 2.1, {text: '1 GERAKAN', y: 110, size: 190}),
  ]},
  // 38
  {c: [38, 38], img: 'p37', cam: 'left', sfx: [[2.9, 'blip', 0.5], [3.5, 'blip', 0.5], [4.1, 'blip', 0.5], [4.7, 'blip', 0.5], [5.3, 'blip', 0.5]], mg: [
    tag(0.4, 2.5, 'Ceramah Dimulai'),
    m('bars', 2.8, 5.4, {title: 'LEVEL KEMAHIRAN SENJATA', items: [{l: 'LV.1  PISAU & PISTOL', v: 35}, {l: 'LV.2  SENAPAN', v: 52}, {l: 'LV.3  BAHAN PELEDAK', v: 70}, {l: 'LV.4  PEDANG', v: 85}, {l: 'LV.5  APA SAJA JADI SENJATA', v: 100}]}),
  ]},
  // 39
  {c: [39, 39], img: 'p38', cam: 'in', shake: [[6.3, 6.7, 10], [7.0, 7.4, 10], [7.5, 8.0, 10]], flash: [[6.4, '#fff']], sfx: [[2.9, 'blip', 0.6], [6.1, 'whoosh', 0.8], [6.4, 'punch', 1], [7.0, 'punch', 1], [7.5, 'thud', 1], [8.6, 'impact', 0.9]], mg: [
    tag(3.0, 2.8, 'Gurita Di Atas Meja'),
    onoma(6.45, 1.4, 'PLAK!', 560, 400, {size: 180, rot: -8}),
    onoma(7.05, 1.4, 'BLETAK!', 1400, 380, {size: 160, rot: 8}),
    m('counter', 8.4, 1.9, {to: 2, suffix: ' DETIK', y: 140, size: 200, countDur: 0.6, label: 'PERTARUNGAN KELAS SATU SELESAI', color: '#fff'}),
  ]},
  // 40
  {c: [40, 40], img: 'p39', cam: 'in', tone: 'cold', sfx: [[0.5, 'shutter', 0.4], [5.0, 'blip', 0.6], [7.2, 'riser', 0.55]], mg: [
    tag(5.0, 3.4, 'Satu-Satunya Bukti Wajah'),
    tag(7.4, 1.9, 'Tubuh Baru', 1),
  ]},
  // 41
  {c: [41, 41], img: 'p40', cam: 'in', sfx: [[0.2, 'riser', 0.6], [3.8, 'impact', 0.9], [3.9, 'whoosh', 0.7]], flash: [[3.8, '#ffd400']], mg: [
    m('meter', 0.5, 4.4, {label: 'KEKUATAN', from: 5, to: 100, y: 800, x: 520, w: 880, dur: 3.2, color: '#ff2b2b'}),
    tag(0.4, 2.2, 'Kencang, Muda, Sehat'),
    tag(3.9, 1.3, 'Masa Prime!', 0, {color: '#ff3b30', textColor: '#fff'}),
  ]},
  // 42
  {c: [42, 42], img: 'p41', cam: 'out', tone: 'warm', sfx: [[0.3, 'whoosh', 0.5], [2.0, 'blip', 0.6]], mg: [
    tag(0.3, 2, 'Pagi Hari'),
    tag(2.0, 2.2, 'Secara Ajaib', 1),
  ]},
  // 43
  {c: [43, 43], img: 'p42', cam: 'in', amt: 0.12, speed: [[5.5, 7.5, '#ff2b2b']], flash: [[5.6, '#fff']], shake: [[5.6, 6.5, 8]], sfx: [[3.0, 'riser', 0.6], [5.6, 'whoosh', 0.7], [5.65, 'impact', 1], [9.8, 'rumble', 0.7]], mg: [
    m('quote', 0.4, 4.6, {text: 'KALIAN BOLEH TERUS COBA BUNUH GUE', y: 110, size: 72}),
    m('slam', 5.6, 3.8, {text: 'PETER YANG TUA', sub: 'SUDAH TIADA', y: 130, size: 190}),
    m('slam', 9.8, 2.2, {text: 'BERSAMBUNG...', y: 380, size: 170, bar: '#111'}),
  ]},
];

export const FPS = 30;
export const cueTime = (i: number) => cues[i - 1];
export const sceneTimes = SCENES.map((s) => ({start: cues[s.c[0] - 1].start, end: cues[s.c[1] - 1].end}));
export const END_HOLD = 2.4;
export const TOTAL_SEC = cues[cues.length - 1].end + END_HOLD;
export const TOTAL_FRAMES = Math.ceil(TOTAL_SEC * FPS);
export {cues};
