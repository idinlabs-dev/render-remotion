# peter-episode1 — worker 1/5

Project Remotion 4.0.250, 1280x720, 30 fps. Worker ini merender rentang global **0.000s–64.500s** dengan audio narasi, backsound, dan SFX tersinkron.

## Upload ke workflow
1. Rename ZIP worker ini menjadi `peter-episode1.zip`.
2. Upload ke `projects/` pada salah satu dari lima repository/account GitHub. Nama internal wajib tetap `peter-episode1`.
3. Push atau jalankan `Render Remotion` dengan composition `PeterEpisode1`. Workflow pengguna memakai path artifact hard-coded, sehingga nama project ini sengaja tidak diubah.
4. Unduh MP4 dari artifact. Ulangi untuk worker 1–5 di lima akun.

## Gabung hasil
Urutkan worker 1 sampai 5, lalu gabungkan MP4 dengan ffmpeg concat. Karena tiap worker membawa audio yang sudah dipotong melalui `OFFSET`, jangan menambahkan audio lagi.

```bash
for f in peter-episode1-worker-*.mp4; do echo "file '$PWD/$f'"; done > concat.txt
ffmpeg -f concat -safe 0 -i concat.txt -c copy peter-episode1-final.mp4
```

Workflow akan melakukan install dependency, memastikan Chromium Remotion, render split internal 60 detik, lalu upload artifact `work/peter-episode1/out/peter-episode1.mp4`.
