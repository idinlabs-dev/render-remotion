// Timing source is generated from peter.srt and verified against the narasi.mp3 duration.
// GitHub workflow reads src/timing.json; rerun this script after replacing audio/SRT.
const fs=require('fs'); const s=JSON.parse(fs.readFileSync('src/timing.json','utf8')); console.log(`duration=${s.duration}s fps=${s.fps} sentences=${s.sentences.length}`);
