export const theme = {
  width: 1280, height: 720, fps: 30, duration: 322.273,
  colors: { bg: "#EAF6FF", paper: "#FFFFFF", ink: "#1B2A3A", blue: "#2D9CDB", teal: "#00BFA6", yellow: "#FFC93C", orange: "#FF8A3D", red: "#FF5D5D", mist: "#CDEEFB", navy: "#6B8FA8" },
  shadow: "rgba(27,42,58,.22)",
  timeline: { reveal: 243.931, fight: 263.0, prime: 303.325 },
};
export const clamp=(x:number,a=0,b=1)=>Math.max(a,Math.min(b,x));
export const ease=(x:number)=>1-Math.pow(1-clamp(x),3);
export const hash=(n:number)=>{const x=Math.sin(n*127.1+311.7)*43758.5453;return x-Math.floor(x)};
