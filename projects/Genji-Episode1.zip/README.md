# Genji — Episode 01 (Comic Action Mafia)

Remotion project in 16:9 (1920×1080), 30 fps. The film follows the supplied RAW narration and its 31 timestamp cues (total 310.845 seconds). Each cue is paired to one individually illustrated panel. `src/cues.json` preserves the full RAW timestamp text and wording; `src/Video.tsx` handles slow camera motion, captions, graphic callouts, narration, music and SFX.

## Render

```sh
npm install
npx remotion browser ensure
npm run render
```

Composition ID: `Genji`. The GitHub render runner reads `render.json` and `src/timing.json` and stitches the output in 60-second chunks. Source audio is in `public/audio/narration.mp3`; original noir score is in `public/audio/music.mp3`; reusable sound effects are in `public/sfx/`; scene panels are in `public/img/`.
