import React from 'react';
import {Composition} from 'remotion';
import {GenjiVideo} from './Video';
import cues from './cues.json';

const FPS = 30;
const duration = cues[cues.length - 1]?.end ?? 310.845;
export const Root: React.FC = () => (
  <Composition id="Genji" component={GenjiVideo} durationInFrames={Math.ceil(duration * FPS)} fps={FPS} width={1920} height={1080} />
);
