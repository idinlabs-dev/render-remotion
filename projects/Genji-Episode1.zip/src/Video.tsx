import React from 'react';
import {AbsoluteFill, Audio, Img, Sequence, interpolate, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import cues from './cues.json';

type Cue = {start: number; end: number; text: string};
const CUES = cues as Cue[];
const FPS = 30;
const TOTAL_FRAMES = Math.ceil((CUES[CUES.length - 1]?.end ?? 310.845) * FPS);
const clamp = {extrapolateLeft: 'clamp' as const, extrapolateRight: 'clamp' as const};

const soundEvents: Array<{cue: number; at: number; file: string; volume: number}> = [
  {cue: 1, at: 0, file: 'rumble', volume: 0.28},
  {cue: 5, at: 0.1, file: 'blip', volume: 0.34},
  {cue: 7, at: 0.2, file: 'run', volume: 0.5},
  {cue: 8, at: 0.1, file: 'steps', volume: 0.32},
  {cue: 10, at: 0.15, file: 'heartbeat', volume: 0.42},
  {cue: 12, at: 0.2, file: 'heartbeat', volume: 0.5},
  {cue: 15, at: 0.2, file: 'rumble', volume: 0.32},
  {cue: 17, at: 0.1, file: 'steps', volume: 0.28},
  {cue: 18, at: 0.3, file: 'cough', volume: 0.24},
  {cue: 21, at: 0.35, file: 'impact', volume: 0.34},
  {cue: 23, at: 0.15, file: 'whoosh', volume: 0.33},
  {cue: 24, at: 0.35, file: 'riser', volume: 0.4},
  {cue: 25, at: 0.15, file: 'impact', volume: 0.42},
  {cue: 30, at: 0.25, file: 'knife', volume: 0.28},
  {cue: 28, at: 0.1, file: 'steps', volume: 0.28},
  {cue: 30, at: 0.2, file: 'blip', volume: 0.24},
  {cue: 31, at: 0.25, file: 'rumble', volume: 0.34},
];

const Panel: React.FC<{cue: Cue; index: number}> = ({cue, index}) => {
  const frame = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();
  const progress = frame / Math.max(1, durationInFrames - 1);
  const zoom = interpolate(progress, [0, 1], [1.045, index % 2 ? 1.12 : 1.105]);
  const drift = interpolate(progress, [0, 1], [index % 2 ? 18 : -18, index % 2 ? -18 : 18]);
  const opacity = interpolate(frame, [0, 10, durationInFrames - 10, durationInFrames], [0, 1, 1, 0.94], clamp);
  return (
    <AbsoluteFill style={{backgroundColor: '#050609', opacity, overflow: 'hidden'}}>
      <Img src={staticFile(`img/p${String(index + 1).padStart(2, '0')}.jpg`)} style={{width: '100%', height: '100%', objectFit: 'cover', transform: `scale(${zoom}) translateX(${drift}px)`, filter: 'saturate(.88) contrast(1.07)'}} />
      <AbsoluteFill style={{background: 'linear-gradient(180deg, rgba(4,7,12,.35) 0%, transparent 20%, transparent 57%, rgba(4,6,10,.74) 100%)'}} />
      <MotionGraphic cueNo={index + 1} text={cue.text} />
      <div style={{position: 'absolute', right: 40, top: 32, color: 'rgba(255,255,255,.92)', fontFamily: 'Arial,sans-serif', fontWeight: 900, fontSize: 24, letterSpacing: 4, textShadow: '2px 3px 0 #000', background: 'rgba(9,12,18,.46)', padding: '7px 15px', borderLeft: '4px solid #a92537'}}>GENJI  •  EPISODE 01</div>
      <Subtitle cue={cue} />
      <div style={{position: 'absolute', left: 20, right: 20, bottom: 17, height: 5, background: 'rgba(255,255,255,.22)'}}>
        <div style={{height: '100%', width: `${((cue.start + progress * (cue.end - cue.start)) / CUES[CUES.length - 1].end) * 100}%`, background: '#b72032'}} />
      </div>
    </AbsoluteFill>
  );
};

const Subtitle: React.FC<{cue: Cue}> = ({cue}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const words = cue.text.split(/\s+/);
  const totalChars = Math.max(1, words.reduce((a, w) => a + w.length + 1, 0));
  const spoken = Math.min(1, (frame / fps) / Math.max(0.1, cue.end - cue.start) * 1.06);
  let sum = 0;
  return (
    <div style={{position: 'absolute', left: 110, right: 110, bottom: 52, display: 'flex', justifyContent: 'center'}}>
      <div style={{maxWidth: 1690, padding: '13px 28px 16px', background: 'rgba(6,8,12,.88)', border: '3px solid #08090c', outline: '2px solid rgba(210,174,74,.92)', boxShadow: '7px 7px 0 rgba(0,0,0,.48)', textAlign: 'center'}}>
        <div style={{fontFamily: 'Arial,sans-serif', fontWeight: 700, fontSize: cue.text.length > 145 ? 32 : cue.text.length > 105 ? 36 : 41, lineHeight: 1.24, letterSpacing: .25}}>
          {words.map((word, i) => {
            const fraction = sum / totalChars;
            sum += word.length + 1;
            return <span key={i} style={{color: spoken >= fraction ? '#fff' : 'rgba(255,255,255,.48)'}}>{word}{i < words.length - 1 ? ' ' : ''}</span>;
          })}
        </div>
      </div>
    </div>
  );
};

const MotionGraphic: React.FC<{cueNo: number; text: string}> = ({cueNo}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const enter = interpolate(f, [0, 12], [0, 1], clamp);
  const tagStyle: React.CSSProperties = {position: 'absolute', left: 58, top: 74, color: '#fff', background: 'rgba(8,10,14,.78)', borderLeft: '6px solid #b72032', padding: '10px 19px', fontFamily: 'Arial,sans-serif', fontWeight: 900, fontSize: 26, letterSpacing: 2, textShadow: '2px 3px 0 #000', transform: `translateX(${(1-enter)*-24}px)`, opacity: enter};
  const bigStyle: React.CSSProperties = {position: 'absolute', right: 75, top: 128, color: '#f8e8c2', background: 'rgba(9,10,14,.76)', border: '2px solid rgba(209,175,98,.85)', padding: '13px 20px', fontFamily: 'Arial,sans-serif', fontWeight: 900, fontSize: 28, letterSpacing: 1.2, textAlign: 'center', textShadow: '2px 3px 0 #000', transform: `scale(${0.92 + enter*.08})`, opacity: enter};
  const label = cueNo === 2 ? 'SUZURAN • HARI KELULUSAN' : cueNo === 8 ? 'MARKAS TAKIYA GUMI' : cueNo === 15 ? 'SELAMAT JALAN, KETUA' : cueNo === 30 ? 'DI SINI TAK ADA ATURAN DUEL' : '';
  return <>
    {label ? <div style={tagStyle}>{label}</div> : null}
    {cueNo === 5 ? <div style={bigStyle}>☎  PANGGILAN MASUK<br/><span style={{color:'#e7c978',fontSize:20}}>IZAKI SHUN</span></div> : null}
    {cueNo === 11 ? <div style={{...tagStyle,top:135,fontSize:22}}>SERANGAN JANTUNG <span style={{color:'#e17b83'}}>　♥ ━╱╲━━╱╲━</span></div> : null}
    {cueNo === 23 ? <div style={bigStyle}><span style={{fontSize:36,color:'#e8c26d'}}>300</span> ANGGOTA<br/><span style={{fontSize:36,color:'#e8c26d'}}>15</span> BISNIS</div> : null}
    {cueNo === 25 ? <div style={tagStyle}>WASIAT SANG KETUA</div> : null}
    {cueNo === 23 ? <div style={{...bigStyle, fontSize:33, color:'#ffe9b0'}}>JANJI DI DEPAN ABU AYAH<br/><span style={{fontSize:48,color:'#d73748'}}>1 TAHUN</span></div> : null}
    {cueNo === 31 ? <div style={{...bigStyle,top:145,maxWidth:600,color:'#fff',borderColor:'#b72032'}}>PESAN TERKIRIM<br/><span style={{color:'#e0c276',fontSize:20}}>"Anak itu sudah duduk di kursi ketua. Mulai sesuai rencana."</span></div> : null}
    {cueNo === 7 ? <div style={{position:'absolute',left:0,right:0,top:0,height:'52%',opacity:.15,background:'repeating-linear-gradient(170deg,transparent 0 44px,rgba(220,230,255,.8) 46px,transparent 49px)'}} /> : null}
    <div style={{position:'absolute',left:50,top:35,color:'rgba(255,255,255,.28)',fontSize:14,fontFamily:'Arial',letterSpacing:2}}>TAKIYA GUMI / FILE 01</div>
  </>;
};

export const GenjiVideo: React.FC = () => {
  const starts = CUES.map(c => Math.round(c.start * FPS));
  const musicVolume = (frame: number) => {
    const ramp = interpolate(frame, [0, 75, TOTAL_FRAMES - 150, TOTAL_FRAMES - 3], [0, 0.19, 0.19, 0], clamp);
    return ramp;
  };
  return (
    <AbsoluteFill style={{backgroundColor:'#000'}}>
      {CUES.map((cue, i) => {
        const from = starts[i];
        const end = i < CUES.length - 1 ? starts[i + 1] : TOTAL_FRAMES;
        return <Sequence key={i} from={from} durationInFrames={Math.max(1,end-from)}><Panel cue={cue} index={i}/></Sequence>;
      })}
      <Audio src={staticFile('audio/narration.mp3')} volume={1}/>
      <Audio src={staticFile('audio/music.mp3')} volume={musicVolume} loop/>
      {soundEvents.map((event, i) => {
        const cueIndex = event.cue - 1;
        const from = (starts[cueIndex] ?? 0) + Math.round(event.at * FPS);
        return <Sequence key={`${event.cue}-${i}`} from={from} durationInFrames={Math.round(4.5*FPS)}><Audio src={staticFile(`sfx/${event.file}.mp3`)} volume={event.volume}/></Sequence>;
      })}
    </AbsoluteFill>
  );
};
